$(document).ready(function(){
    var userId = '{{ user.Id }}';

    //If user logged in, hide the contact section
    if (userId) {
        $('table[data-name="tab_TestDrive_sectionContact"]').closest('fieldset').hide();
    }
});