$(document).ready(function() {
    $("#msauto_devicemodelid").change(function() {
        $("table[data-name='tab_3_section_1'] > tbody > tr:eq(1) > td:eq(0)").text($(this).val());
    });
});